﻿configuration EntApp1SqlDsc 
{
    param
    (
        [Parameter(Mandatory = $true)]
        [System.Management.Automation.PSCredential]
        $SqlAdministratorCredential
    ) 
    Import-DscResource -ModuleName xPSDesiredStateConfiguration
    Import-DscResource -ModuleName SqlServerDsc
    Node localhost
    {
        SqlDatabase UmbracoDB {
            Ensure               = "Present"
            InstanceName         = "MSSQLSERVER"
            Name                 = "umbraco-cms"
            OwnerName            = "sa"
            PsDscRunAsCredential = $SqlAdministratorCredential
        }
        LocalConfigurationManager {
            RebootNodeIfNeeded = $True
        }
    }
} 