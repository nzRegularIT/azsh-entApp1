﻿configuration EnableWindowsFeature 
{ 
    Node localhost
    {
        WindowsFeature IIS { 
            Ensure = "Present" 
            Name   = "Web-Server"
        }
        WindowsFeature ASP {
            Ensure = "Present"
            Name   = "Web-Asp-Net45"
        }
        WindowsFeature IIS-Mgmt-Console {
            Ensure = "Present"
            Name   = "Web-Mgmt-Console"
        }
        Archive Umbraco {
            Ensure      = "Present"
            Destination = "C:\inetpub\CMS"
            Path        = "http://umbracoreleases.blob.core.windows.net/download/UmbracoCms.7.15.5.zip"
        }
        LocalConfigurationManager {
            RebootNodeIfNeeded = $True
        }
    }
} 