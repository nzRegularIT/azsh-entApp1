﻿configuration EnableWindowsFeature 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$featureName
        
    ) 

    Node localhost
    {
        WindowsFeature $featureName
        { 
            Ensure = "Present" 
            Name = $featureName
        }
        
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $True
        }
   }
} 