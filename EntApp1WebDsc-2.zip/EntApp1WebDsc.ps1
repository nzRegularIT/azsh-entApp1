﻿configuration EntApp1WebDsc 
{ 
    Import-DscResource -ModuleName xPSDesiredStateConfiguration
    Import-DscResource -ModuleName xWebAdministration
    Import-DscResource -ModuleName cNtfsAccessControl
    Node localhost
    {
        WindowsFeature IIS { 
            Ensure = "Present" 
            Name   = "Web-Server"
        }
        WindowsFeature ASP {
            Ensure    = "Present"
            Name      = "Web-Asp-Net45"
            DependsOn = "[WindowsFeature]IIS"
        }
        WindowsFeature IIS-Mgmt-Console {
            Ensure    = "Present"
            Name      = "Web-Mgmt-Console"
            DependsOn = "[WindowsFeature]IIS"
        }
        File UmbracoFolder {
            DestinationPath = "C:\inetpub\CMS"
            Type            = "Directory"
            Ensure          = "Present"
            DependsOn       = "[WindowsFeature]IIS"
        }
        File sourceFolder {
            DestinationPath = "C:\source"
            Type            = "Directory"
            Ensure          = "Present"
        }
        xRemoteFile UmbracoZip {
            Uri             = "http://umbracoreleases.blob.core.windows.net/download/UmbracoCms.7.15.5.zip"
            DestinationPath = "C:\source"
            DependsOn       = "[File]sourceFolder"
            
        }
        Archive UmbracoUnzip {
            Path        = "C:\source\UmbracoCms.7.15.5.zip"
            Destination = "C:\inetpub\CMS"
            DependsOn   = @("[xRemoteFile]UmbracoZip", "[File]UmbracoFolder")
        }
        cNtfsPermissionEntry UmbracoFolderPerm {
            Ensure                   = "Present"
            Path                     = "C:\inetpub\CMS"
            Principal                = "ENTAPP1WEB\IIS_IUSRS"
            AccessControlInformation = cNtfsAccessControlInformation {
                AccessControlType = "Allow"
                FileSystemRights  = "Modify"
                Inheritance       = "ThisFolderSubfoldersAndFiles"
            }
            DependsOn                = @("[File]UmbracoFolder", "[WindowsFeature]IIS")
        }
        xWebsite DefaultSite {
            Ensure       = "Present"
            Name         = "Default Web Site"
            State        = "Stopped"
            PhysicalPath = "C:\inetpub\wwwroot"
            BindingInfo  = MSFT_xWebBindingInformation {
                Protocol = "http"
                Port     = "8080"
            }
            DependsOn    = "[WindowsFeature]IIS"
        }
        xWebAppPool UmbracoWebAppPool {
            Name      = "Umbraco"
            Ensure    = "Present"
            State     = "Started"
            autoStart = $True
            DependsOn = "[WindowsFeature]IIS"
        }
        xWebSite UmbracoWebSite {
            Name            = "Umbraco"
            Ensure          = "Present"
            State           = "Started"
            ServerAutoStart = $True
            PhysicalPath    = "C:\inetpub\CMS"
            ApplicationPool = "Umbraco"
            BindingInfo     = MSFT_xWebBindingInformation {
                Protocol = "http"
                Port     = "80"
            }
            DependsOn       = @("[Archive]UmbracoUnzip", "[cNtfsPermissionEntry]UmbracoFolderPerm", "[WindowsFeature]IIS", "[xWebsite]DefaultSite", "[xWebAppPool]UmbracoWebAppPool")
        }
        LocalConfigurationManager {
            RebootNodeIfNeeded = $True
        }
    }
} 