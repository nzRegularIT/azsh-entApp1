﻿configuration EnableWindowsFeature 
{ 
    Import-DscResource -ModuleName xPSDesiredStateConfiguration
    Node localhost
    {
        WindowsFeature IIS { 
            Ensure = "Present" 
            Name   = "Web-Server"
        }
        WindowsFeature ASP {
            Ensure = "Present"
            Name   = "Web-Asp-Net45"
            DependsOn = "[WindowsFeature]IIS"
        }
        WindowsFeature IIS-Mgmt-Console {
            Ensure = "Present"
            Name   = "Web-Mgmt-Console"
            DependsOn = "[WindowsFeature]IIS"
        }
        File UmbracoFolder {
            DestinationPath = "C:\inetpub\CMS"
            Type = "Folder"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]IIS"
        }
        xRemoteFile UmbracoZip {
            Uri = "http://umbracoreleases.blob.core.windows.net/download/UmbracoCms.7.15.5.zip"
            DestinationPath = "C:\inetpub\CMS"
            DependsOn = "[File]UmbracoFolder"
            
        }
        LocalConfigurationManager {
            RebootNodeIfNeeded = $True
        }
    }
} 