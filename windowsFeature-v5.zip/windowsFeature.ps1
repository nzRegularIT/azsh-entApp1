﻿configuration EnableWindowsFeature 
{ 
    Import-DscResource -ModuleName xPSDesiredStateConfiguration
    Node localhost
    {
        WindowsFeature IIS { 
            Ensure = "Present" 
            Name   = "Web-Server"
        }
        WindowsFeature ASP {
            Ensure    = "Present"
            Name      = "Web-Asp-Net45"
            DependsOn = "[WindowsFeature]IIS"
        }
        WindowsFeature IIS-Mgmt-Console {
            Ensure    = "Present"
            Name      = "Web-Mgmt-Console"
            DependsOn = "[WindowsFeature]IIS"
        }
        File UmbracoFolder {
            DestinationPath = "C:\inetpub\CMS"
            Type            = "Directory"
            Ensure          = "Present"
            DependsOn       = "[WindowsFeature]IIS"
        }
        File sourceFolder {
            DestinationPath = "C:\source"
            Type            = "Directory"
            Ensure          = "Present"
        }
        xRemoteFile UmbracoZip {
            Uri             = "http://umbracoreleases.blob.core.windows.net/download/UmbracoCms.7.15.5.zip"
            DestinationPath = "C:\source"
            DependsOn       = "[File]sourceFolder"
            
        }
        Archive UmbracoUnzip {
            Path        = "C:\source\UmbracoCms.7.15.5.zip"
            Destination = "C:\inetpub\CMS"
            DependsOn   = @("[xRemoteFile]UmbracoZip", "[File]UmbracoFolder")
        }
        LocalConfigurationManager {
            RebootNodeIfNeeded = $True
        }
    }
} 